#include "SolarSystem.h"

using namespace std;

SolarSystem::SolarSystem()
{
	window = { 1280, 720 };
	InitWindow(window.x, window.y, "SolarSystem");
	SetTargetFPS(60);
	center = { GetScreenWidth() / 2.f, GetScreenHeight() / 2.f };
}

void SolarSystem::run()
{
	while (!WindowShouldClose())
	{
		BeginDrawing();
		ClearBackground(BLACK);
		DrawCircleV(center, sunSize, YELLOW);
		EndDrawing();
	}
	CloseWindow();
}

int main()
{
	auto obj = make_unique<SolarSystem>();
	obj->run();

	return 0;
}