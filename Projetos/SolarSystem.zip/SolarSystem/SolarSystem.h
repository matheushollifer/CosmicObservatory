#pragma once

#include "raylib.h"
#include <memory>

class SolarSystem
{
private:
	const float sunSize = 60.f;
	Vector2 window, center;

public:
	SolarSystem();
	void run();
};

